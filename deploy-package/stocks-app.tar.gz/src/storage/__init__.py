# Storage module for time-series market data
